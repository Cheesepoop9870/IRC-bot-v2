from local_googlesearch_python import search
results = list(search("hi"))  # Replace 'your_arguments' with your actual arguments
print(results)