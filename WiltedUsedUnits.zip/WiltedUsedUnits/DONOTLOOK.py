a = "python"
b = "is"
c = "excellent"
print(a[0] + c[0] + a[len(a)-1] + b)